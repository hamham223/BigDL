#include <fstream>
#include <string>
#include <iostream>
#include <sstream>

using namespace std;

int main() {

    string line;

    ifstream fin;
    fin.open("u.item");
    ofstream fout;
    fout.open("u.item.comp");

    while (getline(fin, line)){
        istringstream in;
        in.str(line);
        //int user; in >> user;
        int item; in >> item;
        if (item%5==0)
            fout << line << endl;
    }
        

    return 0;
}